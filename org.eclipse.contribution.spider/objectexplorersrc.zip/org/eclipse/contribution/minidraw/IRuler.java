package org.eclipse.contribution.minidraw;

import org.eclipse.swt.graphics.Point;

public interface IRuler {
	Point measure(String s);

}
