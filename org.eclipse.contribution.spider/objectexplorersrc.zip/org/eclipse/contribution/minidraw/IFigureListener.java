package org.eclipse.contribution.minidraw;

public interface IFigureListener {
	void changed(IFigure changed);
}
